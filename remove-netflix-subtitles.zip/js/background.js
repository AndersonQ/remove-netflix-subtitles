'use strict';

function getCodeToInitSubtitlesManager() {
  // This code being returned is the compiled form of src/js/subtitle_manager.js
  // DO NOT CHANGE IT!! Instead, change src/js/subtitle_manager.js and paste its compiled form here
  return '\nif (window.subtitlesManager === undefined) {\n  window.subtitlesManager = function () {\n    var subtitlesObserver = void 0;\n    var subtitlesDiv = void 0;\n    var subtitlesStatus = \'shown\';\n\n    return {\n      status: function status() {\n        return subtitlesStatus;\n      },\n\n      hide: function hide() {\n        if (subtitlesObserver === undefined) {\n          subtitlesObserver = new MutationObserver(function (mutations) {\n            var _subtitlesDiv = mutations[0];\n            _subtitlesDiv.target.style.visibility = \'hidden\';\n          });\n        }\n\n        if (subtitlesDiv === undefined) {\n          subtitlesDiv = document.getElementsByClassName(\'player-timedtext\')[0];\n        }\n\n        subtitlesObserver.observe(subtitlesDiv, {\n          attributes: true,\n          attributeFilter: [\'style\']\n        });\n        subtitlesStatus = \'hidden\';\n        chrome.runtime.sendMessage({ subtitlesStatus: subtitlesStatus });\n      },\n\n      show: function show() {\n        if (subtitlesDiv) {\n          subtitlesObserver.disconnect();\n          subtitlesDiv = undefined;\n          subtitlesStatus = \'shown\';\n          chrome.runtime.sendMessage({ subtitlesStatus: subtitlesStatus });\n        }\n      }\n    };\n  }();\n}\n';
}

function getCodeToHideSubtitles() {
  return 'subtitlesManager.hide();';
}

function getCodeToShowSubtitles() {
  return 'subtitlesManager.show();';
}

function getCodeToToggleSubtitles() {
  return '\n    console.log(\'getCodeToToggleSubtitles\' + subtitlesManager);\n    console.log(\'status: \' + subtitlesManager.status())\n    switch(subtitlesManager.status()) {\n      case \'hidden\':\n          ' + getCodeToShowSubtitles() + '\n          break;\n      case \'shown\':\n          ' + getCodeToHideSubtitles() + '\n          break;\n      default:\n          console.log(\'Unknown status: \' + subtitlesManager.status())\n    }\n  ';
}

function toggleSubtitles() {
  chrome.tabs.executeScript({
    code: getCodeToInitSubtitlesManager()
  });

  chrome.tabs.executeScript({
    code: getCodeToToggleSubtitles()
  });
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  var icon = request.subtitlesStatus === 'hidden' ? 'Red' : 'Green';

  chrome.pageAction.setIcon({
    path: 'img/subtitle' + icon + '.png',
    tabId: sender.tab.id
  });
});

chrome.pageAction.onClicked.addListener(function (tab) {
  return toggleSubtitles();
});

chrome.runtime.onInstalled.addListener(function () {
  chrome.declarativeContent.onPageChanged.removeRules(undefined, function () {
    chrome.declarativeContent.onPageChanged.addRules([{
      conditions: [new chrome.declarativeContent.PageStateMatcher({
        pageUrl: { urlContains: 'netflix',
          pathContains: 'watch'
        }
      })],

      actions: [new chrome.declarativeContent.ShowPageAction()]
    }]);
  });
});