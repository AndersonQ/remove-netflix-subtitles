'use strict';

if (window.subtitlesManager === undefined) {
  window.subtitlesManager = function () {
    var subtitlesObserver = void 0;
    var subtitlesDiv = void 0;
    var subtitlesStatus = 'shown';

    return {
      status: function status() {
        return subtitlesStatus;
      },

      hide: function hide() {
        if (subtitlesObserver === undefined) {
          subtitlesObserver = new MutationObserver(function (mutations) {
            var _subtitlesDiv = mutations[0];
            _subtitlesDiv.target.style.visibility = 'hidden';
          });
        }

        if (subtitlesDiv === undefined) {
          subtitlesDiv = document.getElementsByClassName('player-timedtext')[0];
        }

        subtitlesObserver.observe(subtitlesDiv, {
          attributes: true,
          attributeFilter: ['style']
        });
        subtitlesStatus = 'hidden';
        chrome.runtime.sendMessage({ subtitlesStatus: subtitlesStatus });
      },

      show: function show() {
        if (subtitlesDiv) {
          subtitlesObserver.disconnect();
          subtitlesDiv = undefined;
          subtitlesStatus = 'shown';
          chrome.runtime.sendMessage({ subtitlesStatus: subtitlesStatus });
        }
      }
    };
  }();
}